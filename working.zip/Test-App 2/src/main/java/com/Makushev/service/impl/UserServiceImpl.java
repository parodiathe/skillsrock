package com.Makushev.service.impl;

import com.Makushev.exception.UserException;
import com.Makushev.models.Role;
import com.Makushev.models.User;
import com.Makushev.repository.RoleRepository;
import com.Makushev.repository.UserRepository;
import com.Makushev.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, RoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    @Override
    public User createUser(User user) {
        if (user.getRole() == null && user.getRoleName() != null) {
            Role role = roleRepository.findByRoleName(user.getRoleName())
                    .orElseThrow(() -> new RuntimeException("Role not found: " + user.getRoleName()));
            user.setRole(role);
        }

        return userRepository.save(user);
    }

    @Override
    public User getUserById(UUID UUID) throws UserException {
        return userRepository.findById(UUID)
                .orElseThrow(() -> new UserException("User not found with id: " + UUID));
    }

    @Override
    public User updateUserById(UUID UUID, User updatedUser) throws UserException {

        User existingUser = userRepository.findById(UUID)
                .orElseThrow(() -> new UserException("User not found with id: " + UUID));

        existingUser.setFIO(updatedUser.getFIO());
        existingUser.setPhoneNumber(updatedUser.getPhoneNumber());
        existingUser.setAvatar(updatedUser.getAvatar());
        existingUser.setRole(updatedUser.getRole());

        return userRepository.save(existingUser);
    }

    @Override
    public void deleteUser(UUID UUID) throws UserException {
        if (!userRepository.existsById(UUID)) {
            throw new UserException("User not found with id: " + UUID);
        }

        User user = userRepository.findById(UUID).orElseThrow();
        Role role = user.getRole();

        userRepository.deleteById(UUID);
        roleRepository.delete(role);
    }
}

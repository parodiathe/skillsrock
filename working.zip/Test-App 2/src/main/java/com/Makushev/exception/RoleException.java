package com.Makushev.exception;

public class RoleException extends Exception{

    public RoleException(String message){
        super(message);
    }

}
